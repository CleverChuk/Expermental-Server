#include <stdlib.h>

int main(void)
{
	char *shell[2] = {"/bin/sh","0"}; //temp array
	execve(shell,shell+1,0); // syscall execve

	return 0;
}
