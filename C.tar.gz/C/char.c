#include <stdio.h>


int main()
{
	const char CHAR1 = 134;
	const char CHAR2 = 135;

	char p = (char) CHAR1;
	char q = (char) CHAR2;

	putchar(q);
	putchar('\n');
	putchar(p);
	putchar('\n');

	return 0;
}
