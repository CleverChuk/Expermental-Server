/*shellprogram.c
Kerala Cyber Force – Ajin Abraham */
char code[] = "\x31\xdb\x31\xc0\xb0\x01\xcd\x80";
int main(int argc, char **argv)
{
	int (*exeshell)();
	exeshell = (int (*)()) code;
	(int)(exeshell());
}

