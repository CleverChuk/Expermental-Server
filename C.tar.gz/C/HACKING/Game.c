#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

typedef struct user
{
	char name[40];
	unsigned int score;
	unsigned int credit;
}User;

void set_score(User *puser, unsigned int score)
{
	puser->score = score;
}

unsigned int get_score(User *puser)
{
	return puser->score;
}

void reset_cred(User *puser)
{
	puser->credit = 100;
}

void set_name(User *puser, char name[])
{
	strcpy(puser->name,name);
}

void quit()
{
	exit(0);
}

bool get_guess()
{
	int guess;
	srand(time(0));
	int comp = rand() % 50 + 1;
	
	puts("Enter your guess:");
	scanf("%d",&guess);
	
	printf("You Guessed: %d, Correct Guess: %d	\n",guess,comp);
	return guess == comp;
}

void report(User *puser)
{
	printf("you have %u credits\n",puser->credit);
}

void play(User *puser)
{
	printf("\t\t\t\tGussing Game\n");
	printf("\tTo win credits you have to guess the right Number in the range [0 - 50]\n");

	puts("Enter your name:");
	scanf("%s",puser->name); //Exploit: overflow may be?
	int wager;
	int resp;
	while(1)
	{
		report(puser);

		printf("Enter your wager or Q to quit: ");
		resp = scanf("%d",&wager);
		
		if(resp < 0)
		{
			puts("thanks for playing");
			free(puser);
			quit();
		}
	
		if(get_guess())
		{
			puser->credit += wager;
			printf("You won %d\n",wager);
		}
		else
		{
			puser->credit -= wager;
			printf("You lost %d\n", wager);
		}
	}
		

}


int main(void)
{
	User *player;
	player = (User*) malloc(sizeof(User));
	
	reset_cred(player);
	play(player);

	return 0;
}






































