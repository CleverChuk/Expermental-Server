#include <stdio.h>

int main()
{
	unsigned int addr;
	int i;
	char apl = 'A';
	char *ptr = &apl;
	char *ptr1;
	addr = ptr;
	*((unsigned int *)ptr1) = ptr;

	printf("%p %c| %p %c| %p %c \n", ptr1,*ptr1,ptr,*ptr,addr,addr);
	addr = 45;
	
	printf("%p %u\n",addr);
	return 0;
}
