//test.c -- test concepts
#include <stdio.h>

int main(int argc, char const *argv[])
{
	int i = 5;
	unsigned int j = 3;

	double k = (double)&i - j; // since address is a number you can type cast it

	printf("K = %fd should be 2\n", k);

	return 0;
}