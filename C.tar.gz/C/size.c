#include <stdio.h>

int main()
{
	printf("size of char %u| size of int %u\n",sizeof(char),sizeof(int));
}
