#include <stdio.h>

int func_one(void)
{
	printf("This is funtion one\n");
	return 1;
}

int func_two(void)
{
	printf("This is function two\n");
	return 2;
}

int main(void)
{
	int value;
	int (*pfun)(void);
	
	pfun = func_one;
	printf("function_ptr is 0x%08x\n", pfun);
	value = pfun();
	printf("Value returned was %d\n", value);

	pfun = func_two;
	printf("function_ptr is 0x%08x\n",pfun);
	value = pfun();
	printf("Value returned was %d\n",value);
	
	return 0;
}

